package com.example.haki

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference


class TimeSettings : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timesettings)

        val num_pom_text = findViewById<TextView>(R.id.num_poms) as EditText
        val long_len_text = findViewById<TextView>(R.id.long_break) as EditText
        val short_len_text = findViewById<TextView>(R.id.short_break) as EditText
        val pom_len_text = findViewById<TextView>(R.id.pom_len) as EditText
        val done = findViewById<Button>(R.id.done)

        done.setBackgroundColor(Color.GREEN);

        // uses sharedpreferences to do save the current time setting
        done.setOnClickListener{
            val num_pom = Integer.parseInt(num_pom_text.text.toString())
            var long_len = (long_len_text.text.toString()).toLong()
            long_len=min_to_milis(long_len)
            var short_len = (short_len_text.text.toString()).toLong()
            short_len=min_to_milis(short_len)
            var pom_len = (pom_len_text.text.toString()).toLong()
            pom_len=min_to_milis(pom_len)

            val pref = applicationContext.getSharedPreferences("MyPref", MODE_PRIVATE)
            val editor: SharedPreferences.Editor = pref.edit()

            editor.putInt("num_pom", num_pom);
            editor.putLong("long_len", long_len);
            editor.putLong("short_len", short_len);
            editor.putLong("pom_len", pom_len);
            editor.putBoolean("timerRunning",false)

            // Save the changes in SharedPreferences
            editor.apply(); // commit changes

            num_pom_text.text.clear()
            long_len_text.text.clear()
            short_len_text.text.clear()
            pom_len_text.text.clear()



            val myIntent = Intent(applicationContext,Timer::class.java);
            startActivity(myIntent)
        }

    }

    // object that converts a minute value to a millisecond value
    // this is because the CountDownTimer object class in the "Timer" activity uses milliseconds
    fun min_to_milis(value: Long): Long{
        val mil = value*60000
        return mil
    }

}