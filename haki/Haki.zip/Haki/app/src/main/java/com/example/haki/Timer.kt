package com.example.haki;

import android.annotation.SuppressLint
import android.app.Notification
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.haki.Notifications.Companion.CHANNEL_1_ID
import java.util.*


// uses the built in "countdown timer" object class in Kotlin
// to model a pomodoro timer as a finite state machine

class Timer : AppCompatActivity() {

    private val notificationManager: NotificationManagerCompat? = null
    private var mTextViewCountDown: TextView? = null
    private var mButtonStartPause: Button? = null
    private var mButtonReset: Button? = null
    private var mCountDownTimer: CountDownTimer? = null
    private var mTimerRunning = false
    private var mTimeLeftInMillis: Long = 0
    private var mEndTime: Long = 0
    private var long_break_check=false
    private var short_break_check=false
    private var mpomodoros: TextView?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)


        mTextViewCountDown = findViewById(R.id.text_view_countdown)
        mButtonStartPause = findViewById(R.id.button_start_pause) as? Button
        mButtonReset = findViewById(R.id.button_reset) as? Button
        mpomodoros= findViewById(R.id.pomodoros) as TextView

        val notificationManager: NotificationManagerCompat = NotificationManagerCompat.from(this);


        val prefs = getSharedPreferences("MyPref", MODE_PRIVATE)

        var num_pom: Int = prefs.getInt("num_pom",0)

        var pom_len: Long = prefs.getLong("pom_len",0)

        var long_break: Long = prefs.getLong("long_break",0)

        var short_break: Long = prefs.getLong("short_break",0)

        Log.d("pom_len", pom_len.toString())

        mButtonStartPause?.setOnClickListener(View.OnClickListener {
            if (mTimerRunning) {
                pauseTimer()
            } else {
                startTimer()
            }
        })
        mButtonReset?.setOnClickListener(View.OnClickListener { resetTimer() })

        mpomodoros!!.text= num_pom.toString()

    }

    fun sendOnChannel1(view: View?) {
        val title: String = "Text"
        val message: String = mTextViewCountDown?.text.toString()
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_1_ID)
            .setSmallIcon(R.drawable.ic_add)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .build()
        if (notificationManager != null) {
            notificationManager.notify(1, notification)
        }
    }


    // state for when the timer is running
    private fun startTimer() {
        mEndTime = System.currentTimeMillis() + mTimeLeftInMillis
        mCountDownTimer = object : CountDownTimer(mTimeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                mTimeLeftInMillis = millisUntilFinished
                updateCountDownText()
            }
            // state for when the timer finishes
            override fun onFinish() {
                mTimerRunning = false
                updateButtons()
            }
        }.start()
        mTimerRunning = true
        updateButtons()
    }

    //state for when the timer is paused

    private fun pauseTimer() {
        mCountDownTimer!!.cancel()
        mTimerRunning = false
        updateButtons()
    }

    // state for when the timer is resetted
    private fun resetTimer() {
        val prefs = getSharedPreferences("MyPref", MODE_PRIVATE)
        mTimeLeftInMillis = prefs.getLong("pom_len",0)
        updateCountDownText()
        updateButtons()
    }

    // updtaees the "mTextViewCountDown" view with the current time
    private fun updateCountDownText() {
        val minutes = (mTimeLeftInMillis / 1000).toInt() / 60
        val seconds = (mTimeLeftInMillis / 1000).toInt() % 60
        val timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        mTextViewCountDown?.text = timeLeftFormatted
    }

    // method to model
    private fun updateButtons() {
        val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        pom_len=prefs.getLong("temp_pom_len",0)
        if (mTimerRunning) {
            mButtonReset!!.visibility = View.INVISIBLE
            mButtonStartPause!!.text = "Pause"
            mButtonStartPause!!.setBackgroundColor(Color.RED);
            mButtonStartPause!!.setTextColor(Color.BLACK);
        } else {
            mButtonStartPause?.text = "Start"
            mButtonStartPause!!.setBackgroundColor(Color.GREEN);
            mButtonStartPause!!.setTextColor(Color.BLACK);
            if (mTimeLeftInMillis < 1000) {
                mButtonStartPause!!.visibility = View.INVISIBLE
            } else {
                mButtonStartPause?.visibility = View.VISIBLE
            }
            if (mTimeLeftInMillis < pom_len) {
                mButtonReset!!.visibility = View.VISIBLE
            } else {
                mButtonReset?.visibility = View.INVISIBLE
            }
        }
    }


    override fun onBackPressed() {
        val myIntent = Intent(applicationContext,MainActivity::class.java);
        startActivity(myIntent)
    }



    // uses sharedpreferences to maintain persistence when the activity is closed
    override fun onStop() {
        super.onStop()
        val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putLong("temp_pom_len", mTimeLeftInMillis)
        editor.putBoolean("timerRunning", mTimerRunning)
        editor.putLong("endTime", mEndTime)
        editor.apply()
        if (mCountDownTimer != null) {
            mCountDownTimer!!.cancel()
        }

        Log.d("mTimeLeftInMillisEND", mTimeLeftInMillis.toString())
    }


    // uses sharedpreferenes to retreive the previous data when the activity starts
    @SuppressLint("CommitPrefEdits")
    override fun onStart() {
        super.onStart()
        val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        mTimeLeftInMillis = prefs.getLong("temp_pom_len", 0)
        mTimerRunning = prefs.getBoolean("timerRunning", false)
        updateCountDownText()
        updateButtons()
        if (mTimerRunning) {
            mEndTime = prefs.getLong("endTime", 0)
            mTimeLeftInMillis = mEndTime - System.currentTimeMillis()
            if (mTimeLeftInMillis < 0) {

                val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
                val num_poms = prefs.getLong("temp_num_pom", 0)
                val editor = prefs.edit()
                editor.putLong("temp_num_pom", num_poms-1)
                editor.apply(); // commit changes
                mTimerRunning = false;
                updateCountDownText();
                resetTimer()
            } else {
                startTimer()
            }
        }
    }

    // usess an intent to go to the TimeSettings activity where the user can change the settings
    // of the timer
    fun gosettings(view: View){
        val myIntent = Intent(applicationContext,TimeSettings::class.java);
        startActivity(myIntent)
    }


    companion object {
        private var num_pom: Int = 4
        private var pom_len: Long = 72000

        private var long_break: Long = 15

        private var short_break: Long = 5


    }
}