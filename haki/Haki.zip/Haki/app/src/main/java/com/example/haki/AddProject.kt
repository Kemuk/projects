package com.example.haki

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import com.example.haki.databinding.ActivityAddProjectBinding
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.temporal.ChronoUnit
import java.util.*


class AddProject : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityAddProjectBinding


    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_project)

        val currentDateTime = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val the_date = currentDateTime.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        val currDate=LocalDate.parse(the_date.toString(), formatter)

        // get the view values
        val projview = findViewById<TextView>(R.id.enterproject) as EditText
        val endDate     = findViewById<TextView>(R.id.dateTv)
        val task_view = findViewById<TextView>(R.id.enter_tasks) as EditText


        // buttons
        val mPickTimeBtn = findViewById<Button>(R.id.pickDateBtn)
        val madd_task = findViewById<Button>(R.id.add_task)
        val done = findViewById<Button>(R.id.finish)

        //val db: SQLiteDatabase = getWritableDatabase()
        val task_list: MutableList<String> = mutableListOf<String>()

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        var month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        mPickTimeBtn.setOnClickListener {

            val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                // Display Selected date in TextView
                if (month<10 && dayOfMonth<10) {
                    month+=1
                    endDate.setText("0$dayOfMonth/0$month/$year")
                }
                else if (month<10) {
                    month+=1
                    endDate.setText("$dayOfMonth/0$month/$year")
                }
                else if (dayOfMonth<10){
                    month+=1
                    endDate.setText("0$dayOfMonth/$month/$year")
                }
                else{
                    month+=1
                    endDate.setText("$dayOfMonth/$month/$year")
                }
            }, year, month, day)
            dpd.show()
        }

        //db.beginTransaction();
        madd_task.setOnClickListener{
            task_list.add(task_view.text.toString())
            task_view.getText().clear()
            Toast. makeText(applicationContext,task_view.text.toString() +"was added",Toast. LENGTH_SHORT)
        }



        done.setOnClickListener{

            val end = endDate.text

            val endTimeDate = LocalDate.parse(end, formatter)


            val difference= ChronoUnit.DAYS.between(currDate, endTimeDate)

            val db: dbhandler = dbhandler(applicationContext)

            val database= db.writableDatabase

            var cv = ContentValues()

            cv.put("name", projview.text.toString())
            cv.put("start_date", currDate.toString())
            cv.put("end_date",endDate.text.toString())
            cv.put("time",difference)
            cv.put("status",0)
            var result: Long = database.insert("Projects", null, cv)

            cv = ContentValues()

            cv.put("project_name", projview.text.toString())


            for (item in task_list) {
                cv.put("task_name", item)
                cv.put("status", 0)
            }

            result = database.insert("Tasks", null, cv)

            val myIntent = Intent(applicationContext,MainActivity::class.java);
            startActivity(myIntent)
        }

    }

}
