package com.example.haki


import android.database.Cursor
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*


class ViewListContents : AppCompatActivity() {
    var myDB: dbhandler? = null
    var TABLE_NAME =  "Projects"
    var TABLE2_NAME = "Tasks"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.viewlistcontents_layout)
        val listView = findViewById<View>(R.id.listView) as ListView
        myDB = dbhandler(this)

        //populate an ArrayList<String> from the database and then view it
        val theList = ArrayList<String>()
        val data: Cursor? = myDB!!.getListContents(TABLE_NAME)
        val data2: Cursor? =  myDB!!.getListContents(TABLE2_NAME)

        if (data != null) {
            if (data.count == 0) {
                Toast.makeText(this, "There are no contents in this list!", Toast.LENGTH_LONG).show()
            } else {
                if (data != null) {
                    while (data.moveToNext()) {
                        if (data != null) {
                            var name = data.getString(1)
                            var list_string = (name +  " Due on: " + data.getString(3))
                            if (data2 != null) {
                                while (data2.moveToNext()) {
                                    if (data2.getString(1)==name){
                                        list_string+=("Tasks: "+data2.getString(2))
                                    }
                                }
                            }
                            theList.add(list_string)
                        }
                        val listAdapter: ListAdapter =
                            ArrayAdapter(this, R.layout.simple_list_item_1, theList)
                        listView.adapter = listAdapter
                    }
                }
            }
        }
    }
}