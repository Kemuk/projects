package com.example.haki

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*


class MainActivity : AppCompatActivity() {

    var myDB : dbhandler? =null
    
    var btnAdd: Button? = null
    var btnView:Button? = null
    var guide:Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnAdd = findViewById<View>(R.id.btnAdd) as Button
        btnView = findViewById<View>(R.id.btnView) as Button
        guide = findViewById<View>(R.id.guide) as Button
        myDB = dbhandler(this)

        btnView!!.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, ViewListContents::class.java)
            startActivity(intent)
        })
        btnAdd!!.setOnClickListener {
            var myIntent = Intent(applicationContext, AddProject::class.java);
            startActivity(myIntent)
        }

        guide!!.setOnClickListener{
            var myIntent = Intent(applicationContext, UserGuide::class.java);
            startActivity(myIntent)
        }
    }


    fun AddData(newEntry: List<String>) {
        myDB = dbhandler(applicationContext)
        val insertData: Boolean = myDB!!.addData(newEntry)
        if (insertData == true) {
            Toast.makeText(this, "Data Successfully Inserted!", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Something went wrong :(.", Toast.LENGTH_LONG).show()
        }
    }

    fun gostats(view: View){
        var myIntent = Intent(applicationContext,Stats::class.java);
        startActivity(myIntent)
    }

    fun gotimer(view: View){
        var myIntent = Intent(applicationContext,Timer::class.java);
        startActivity(myIntent)
    }



    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }


}