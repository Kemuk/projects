package com.example.haki

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class dbhandler (context: Context) : SQLiteOpenHelper(context, "HakiDB", null,1) {




    // table fields
    val table_name = "Projects";
    val Column_PROJECT_ID = "proj_id";
    val Column_NAME = "name"
    val Column_STARTDATE = "start_date"
    val Column_ENDDATE = "end_date"
    val Column_TIME = "time"
    val Column_PROJECT_STATUS = "status"

    val table2_name = "Tasks"
    val Column_TASK_ID = "task_id"
    val Column_PROJECT_NAME = "project_name" // foreign key from the projects table
    val Column_TASK_NAME = "task_name"
    val Column_TASK_STATUS = "status"

     override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_PROJECTS_TABLE = "CREATE TABLE " + table_name + "(" + Column_PROJECT_ID + " INTEGER PRIMARY KEY," + Column_NAME + " TEXT," + Column_STARTDATE + " TEXT," + Column_ENDDATE + " TEXT," + Column_TIME + " INTEGER," + Column_PROJECT_STATUS + " INTEGER)"
        db?.execSQL(CREATE_PROJECTS_TABLE)

        val CREATE_TASKS_TABLE = ("CREATE TABLE " + table2_name + "("
                + Column_TASK_ID + " INTEGER PRIMARY KEY," + Column_PROJECT_NAME + " TEXT,"
                + Column_TASK_NAME + " TEXT," + Column_TASK_STATUS + " INTEGER,"
                + " FOREIGN KEY (" + Column_PROJECT_NAME + ") REFERENCES " + table_name + "(" + Column_NAME + ")" + ")")

        db?.execSQL(CREATE_TASKS_TABLE)


    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS " + table_name)
        onCreate(db)

        db.execSQL("DROP TABLE IF EXISTS " + table2_name)
        onCreate(db)
    }

    fun readAllData(TABLE_NAME: String): Cursor? {
        val query = "SELECT * FROM $TABLE_NAME"
        val db = this.readableDatabase
        var cursor: Cursor? = null
        if (db != null) {
            cursor = db.rawQuery(query, null)
        }
        return cursor
    }

    fun deleteAllData() {
        val db = this.writableDatabase
        db.execSQL("DELETE FROM $table_name")
        db.execSQL("DELETE FROM $table2_name")
    }

    fun getListContents(TABLE_NAME: String): Cursor? {
        val db = this.writableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }

    fun addData(item1: List<String>?): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()

        contentValues.put(Column_NAME, item1?.get(0))
        contentValues.put(Column_STARTDATE, item1?.get(1))
        contentValues.put(Column_ENDDATE, item1?.get(2))
        contentValues.put(Column_TIME, item1?.get(3))
        contentValues.put(Column_PROJECT_STATUS, item1?.get(4))

        val result = db.insert(table_name, null, contentValues)

        //if date as inserted incorrectly it will return -1
        return if (result == -1L) {
            false
        } else {
            true
        }
    }
}
